// Grades.h
#ifndef _GRADES_H_
#define _GRADES_H_
#include <iostream>
#include <string>
#include<stdint.h>
#include <fstream>

using namespace std;

class Grades
{
private:
	string* studNum;
	double* mark;
	int count;
	Grades(const Grades& g);
	Grades& operator=(const Grades& g);
	Grades(Grades&& g);
public:
	Grades() : studNum(nullptr), mark(nullptr), count(0){ }
	Grades(char* file){
		try{
			ifstream fs(file);
			if (fs.is_open()){
				int _count = 0;
				string s;
				while (getline(fs, s))
					_count++;
				fs.clear();
				fs.seekg(0);
				count = _count;
				studNum = new string[count];
				mark = new double[count];
				for (uint64_t i = 0; i < count; i++){
					fs >> studNum[i];
					fs >> mark[i];
				}
				fs.close();
			}
			else throw "Failed to open file.";
		}
		catch (const char* msg){
			cerr << "aaaa" << msg << "\n";
			exit(0);
		}
		catch (ifstream::failure e){
			cerr << "Exception opening error" << "\n";
		}
		catch (...){
			std::cout << "bbbb" << "\n";
		}
	}

	template<typename TYPE>
	void displayGrades(std::ostream& os, TYPE type) const{
		for (int i = 0; i < count; i++)
			os << studNum[i] << " " << mark[i] << " " << type(mark[i]) << endl;
	}
};
#endif
