//DataTable.h

#pragma once

#include <vector>//for vector arrays x and y
#include <cmath>//for sqrt
#include <numeric>//accumulate()
#include <algorithm>//sort()


using namespace std;

namespace w8 {
	//"Code a class template named DataTable for performing statistical 
	//analysis on data stored in text files."
	//syntax - template <class a_type> class a_class {...};
	template<typename T>
	class DataTable {
		vector<T> x;
		vector<T> y;
		
		int FW;//FW short for field width
		int ND;//ND short for number of decimals
		
	public:
		//ctor
		//"a reference to the file stream" - fstream& in
		//"the field width for displaying the data" -int field_width
		//"the number of decimals to display" - int number_of_decimals
		DataTable(ifstream& in, int field_width, int number_of_decimals){
			FW = field_width;
			ND = number_of_decimals;
			//"The object retrieves the data values from the file and stores them in its
			//instance variables.  "- the data values are the x and y cordinates  
			//and _x and _y are the instance variables i created below
			T _x, _y;//x and y cordinates
			if(in.is_open()){
				while(!in.eof()){
					in >> _x;//stores x value from the file in _x
					in >> _y;//stores y value from the file in _y
					x.push_back(_x);//pushes _x to the back of vector x
					y.push_back(_y);
				}
			}
		}
		//"– returns the mean value of the dependent coordinate"
		//use accumulate() function to get total value of all elements in the vector 
		T mean() const{
			//syntax - accumulate(first,last,initial)
			T total = accumulate(y.begin(),y.end(), (T)0);
			//             y.size();//return total indexes of the vector
			return total / y.size();//count;//mean = total / count 
		}
		
		//ssd
		T sigma() const{
			T m = mean();
			T sum = 0;
			
			for(size_t i = 0;i < y.size();i++)
			{
				sum += (y.at(i) - m) * (y.at(i) - m);
			}
			return sqrt(static_cast<double>(sum / (y.size() - 1)));
			
		}
				
		// returns the median value of the dependent coordinate
		//number in the middle
		T median() const{
			vector<T> sortthis = this->y;//create a vector that contains same as y
			//sort will sort by value the sortthis vector in between the ranges
			sort(sortthis.begin(), sortthis.end());
			T total = y.size();
			return sortthis[total/2];			
		}
		
		/*void regression(T& slope, T& y_intercept) const{
			
		}*/
		void regression(T& slope, T& y_intercept) const{
			T sum_xy = inner_product(x.begin(), x.end(), y.begin(), (T)0);
			T sum_x = accumulate(x.begin(), x.end(), (T)0);
			T sum_y = accumulate(y.begin(), y.end(), (T)0);
			T sum_sq_x = inner_product(x.begin(), x.end(), x.begin(), (T)0);
			T num = y.size();
			slope = (num * sum_xy - sum_x * sum_y) / (num * sum_sq_x - sum_x * sum_x);
			y_intercept = (sum_y - slope * sum_x) / num;
		}

		void display(ostream& os) const{
			os << setprecision(ND) << fixed << setw(FW) << 'X'; 
			os << setw(FW) << 'Y' << endl;
			for(int i = 0; i < x.size(); i++){
				os << setw(FW) << x[i] << setw(FW) << y[i] << endl;
			}
		}
		friend ostream& operator<<(ostream& os, const DataTable& datatable){
			datatable.display(os);
			return os;
		}			
	
	};//class DataTable

}//namespace w8
