#pragma once
namespace w1 {
   void process(char* c);
}
